const mix = require('laravel-mix');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Here we are defining the assets to be compiled by Laravel Mix.
 |
 */

mix.js('resources/js/app.js', 'public/js')
    .sass('resources/sass/app.scss', 'public/css') // jika menggunakan SASS
    .postCss('resources/css/app.css', 'public/css', [
        require('tailwindcss'),
    ]);
