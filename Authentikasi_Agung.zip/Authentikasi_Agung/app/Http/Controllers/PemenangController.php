<?php

namespace App\Http\Controllers;

use App\Models\PemenangBalonDor;  
use Illuminate\Http\Request;

class PemenangController extends Controller
{
    public function index()
    {
        $pemenangs = PemenangBalonDor::all();
        return view('pemenang.index', compact('pemenangs'));
    }
}
