<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Daftar Pemenang Balondor') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <!-- Tampilkan daftar pemenang -->
                    <table class="min-w-full bg-white dark:bg-gray-800">
                        <thead>
                            <tr class="border-b dark:border-gray-700">
                                <th class="py-2 px-4 text-left text-gray-600 dark:text-gray-400">{{ __('Nama') }}</th>
                                <th class="py-2 px-4 text-left text-gray-600 dark:text-gray-400">{{ __('Negara') }}</th>
                                <th class="py-2 px-4 text-left text-gray-600 dark:text-gray-400">{{ __('Tahun') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($pemenangs as $pemenang)
                                <tr class="border-b dark:border-gray-700">
                                    <td class="py-2 px-4 text-gray-900 dark:text-gray-100">{{ $pemenang->nama }}</td>
                                    <td class="py-2 px-4 text-gray-900 dark:text-gray-100">{{ $pemenang->negara }}</td>
                                    <td class="py-2 px-4 text-gray-900 dark:text-gray-100">{{ $pemenang->tahun }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <!-- Jika tidak ada pemenang -->
                    @if($pemenangs->isEmpty())
                        <p class="text-gray-900 dark:text-gray-100 mt-4">{{ __('Tidak ada pemenang yang ditemukan.') }}</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
